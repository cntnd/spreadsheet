<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_spreadsheet/css/cntnd_spreadsheet.css') ?>
</style>

<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_simple_spreadsheet/assets/jexcel.css') ?>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_simple_spreadsheet/assets/jsuites.css') ?>
</style>

<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_simple_spreadsheet/css/cntnd_simple_spreadsheet.css') ?>
</style>

?><?php
// cntnd_core_input

// input/vars


// other/vars


// includes
//cInclude('module', 'includes/script.cntnd_booking_input.php');
//cInclude('module', 'includes/style.cntnd_booking_input.php');
?>

<?php

/* cntnd_core */
$(document).ready(function(){

});
